The BTK/Examples directory contains some C++ examples showing how to use BTK.

The next listing presents the subdirectories and their contents.

 - ConvertAcquisition: simple acquisition file converter. 
